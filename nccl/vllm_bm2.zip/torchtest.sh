#!/bin/bash

set -ex

exec &> >(tee "test_symmetric_memory.txt")

RESULT_DIR="$(dirname "$(realpath "$0")")/results_p2p"
mkdir -p "$RESULT_DIR"

NSYS_OUT_DMA="$RESULT_DIR/nsys_p2p_copy_dma"
NSYS_OUT_SM="$RESULT_DIR/nsys_p2p_copy_sm"

run_profile_dma() {
    CUDA_VISIBLE_DEVICES=0,1 \
    nsys profile \
        --trace=cuda,nvtx \
        --trace-fork-before-exec=true \
        --output="$NSYS_OUT_DMA" \
        --force-overwrite=true \
        --gpu-metrics-devices=0 \
        --cuda-graph-trace=node \
        python -m pytest \
            /home/sejinoh/venv/source/pytorch/test/distributed/test_symmetric_memory.py \
            -k "test_p2p_copy_uses_dma_engine" -v -s
}

run_profile_sm() {
    CUDA_VISIBLE_DEVICES=0,1 \
    nsys profile \
        --trace=cuda,nvtx \
        --trace-fork-before-exec=true \
        --output="$NSYS_OUT_SM" \
        --force-overwrite=true \
        --gpu-metrics-devices=0 \
        --cuda-graph-trace=node \
        python -m pytest \
            /home/sejinoh/venv/source/pytorch/test/distributed/test_symmetric_memory.py \
            -k "test_p2p_copy_uses_sm" -v -s
}

echo "=========================================="
echo "=== [1/2] DMA Engine (CE) P2P copy test ==="
echo "=========================================="
run_profile_dma

echo ""
echo "=== nsys stats [DMA]: Memcpy (CE check) ==="
nsys stats "$NSYS_OUT_DMA.nsys-rep" \
    --report cuda_gpu_mem_time_sum 2>/dev/null \
    | grep -E "MemCpy|PtoP|DtoD|Total" | head -20

echo ""
echo "=== nsys stats [DMA]: Kernels (SM check) ==="
nsys stats "$NSYS_OUT_DMA.nsys-rep" \
    --report cuda_gpu_kern_sum 2>/dev/null \
    | grep -E "memcpy|copy|kernel|Total" -i | head -20

echo ""
echo "=========================================="
echo "=== [2/2] SM-based P2P copy test        ==="
echo "=========================================="
run_profile_sm

echo ""
echo "=== nsys stats [SM]: Memcpy (CE check) ==="
nsys stats "$NSYS_OUT_SM.nsys-rep" \
    --report cuda_gpu_mem_time_sum 2>/dev/null \
    | grep -E "MemCpy|PtoP|DtoD|Total" | head -20

echo ""
echo "=== nsys stats [SM]: Kernels (SM check) ==="
nsys stats "$NSYS_OUT_SM.nsys-rep" \
    --report cuda_gpu_kern_sum 2>/dev/null \
    | grep -E "memcpy|copy|kernel|Total" -i | head -20

echo ""
echo "Profiles saved:"
echo "  DMA: $NSYS_OUT_DMA.nsys-rep  →  nsys-ui $NSYS_OUT_DMA.nsys-rep"
echo "  SM:  $NSYS_OUT_SM.nsys-rep   →  nsys-ui $NSYS_OUT_SM.nsys-rep"
